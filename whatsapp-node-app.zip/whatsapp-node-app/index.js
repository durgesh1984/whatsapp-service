const { Client, LocalAuth } = require('whatsapp-web.js');
const express = require('express');
const QRCode = require('qrcode');

const app = express();
app.use(express.json());

const clients = new Map(); // sessionId -> Client
const qrCodes = new Map(); // sessionId -> latest QR

// Function to create or get a client for a session ID
const getClient = (sessionId) => {
    if (clients.has(sessionId)) {
        return clients.get(sessionId);
    }

    const client = new Client({
        authStrategy: new LocalAuth({ dataPath: `./sessions/${sessionId}` }),
        puppeteer: {
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        }
    });

    client.on('qr', qr => {
        qrCodes.set(sessionId, qr);
        console.log(`QR received for session: ${sessionId}`);
    });

    client.on('ready', () => {
        console.log(`Client ready for session: ${sessionId}`);
    });

    client.on('authenticated', () => {
        console.log(`Client authenticated for session: ${sessionId}`);
    });

    client.on('auth_failure', () => {
        console.error(`Auth failure for session: ${sessionId}`);
    });

    client.initialize();
    clients.set(sessionId, client);

    return client;
};

// Route to get QR code
app.get('/qr/:sessionId', async (req, res) => {
    const sessionId = req.params.sessionId;
    const client = getClient(sessionId);
    const qr = qrCodes.get(sessionId);

    if (!qr) {
        return res.status(404).send('QR not available. Please wait or refresh.');
    }

    const qrImage = await QRCode.toDataURL(qr);
    res.send(`
        <html>
            <body>
                <h2>Scan QR for session: ${sessionId}</h2>
                <img src="${qrImage}" />
            </body>
        </html>
    `);
});

// Send message using a specific session
app.post('/send', async (req, res) => {
    const { sessionId, number, message } = req.body;

    if (!sessionId || !number || !message) {
        return res.status(400).send('Missing sessionId, number, or message');
    }

    const client = getClient(sessionId);

    try {
        const chatId = `${number.replace(/\D/g, '')}@c.us`;
        await client.sendMessage(chatId, message);
        res.send(`Message sent using session ${sessionId}`);
    } catch (err) {
        console.error(err);
        res.status(500).send('Failed to send message: ' + err.message);
    }
});

// Start server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});

